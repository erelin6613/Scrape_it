from scrape_it import Scrape_it

scrape_it = Scrape_it(url='https://www.all-wall.com', country='us', method='webdriver')

scrape_it.scrape()