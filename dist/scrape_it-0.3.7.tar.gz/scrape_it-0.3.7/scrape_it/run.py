from scrape_it import Scrape_it

scrape_it = Scrape_it(url='https://www.lyvly.uk', country='us', method='webdriver')

scrape_it.scrape()